package com.jianghongkui.customelint;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity5 extends AppCompatActivity {

}
