package com.jianghongkui.customelint;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

}
