package com.jianghongkui.customelint;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

}
